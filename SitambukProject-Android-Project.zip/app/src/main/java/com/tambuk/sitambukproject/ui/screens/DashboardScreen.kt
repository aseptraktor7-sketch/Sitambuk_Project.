package com.tambuk.sitambukproject.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.MainViewModel
import com.tambuk.sitambukproject.ui.components.*
import com.tambuk.sitambukproject.ui.theme.*

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val telemetry by viewModel.telemetry.collectAsState()
    val btState by viewModel.btState.collectAsState()
    val deviceName by viewModel.connectedDeviceName.collectAsState()
    val isStale by viewModel.isDataStale.collectAsState()
    val currentTime by viewModel.currentTime.collectAsState()
    val speed = viewModel.getEffectiveSpeed()
    val speedLabel = viewModel.getSpeedSourceActiveLabel()

    Column(Modifier.fillMaxSize().background(CarbonBlack).padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            StatusHeader("Sitambuk_Project⚡", "DASHBOARD MONITORING", btState,
                deviceName, isStale, currentTime, Modifier.weight(1f))
            IconButton(onClick = onNavigateToSettings) { Icon(Icons.Default.Settings, "Pengaturan", tint = NeonBlue) }
            IconButton(onClick = onNavigateToMap) { Icon(Icons.Default.Map, "Peta", tint = NeonBlue) }
            IconButton(onClick = onNavigateToAbout) { Icon(Icons.Default.Info, "Tentang", tint = NeonBlue) }
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            VerticalBarGauge(Icons.Default.LocalGasStation, "F", "E", telemetry.fuelPercent,
                modifier = Modifier.width(48.dp).fillMaxHeight())
            RpmGauge(telemetry.rpm, Modifier.weight(1f).fillMaxHeight())
            SpeedGauge(speed, speedLabel, Modifier.weight(1f).fillMaxHeight())
            Column(Modifier.width(78.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly,
                horizontalAlignment = Alignment.CenterHorizontally) {
                StatusLamp("AKI", "${"%.1f".format(telemetry.batteryVoltage)} V", telemetry.batteryVoltage > 0f)
                StatusLamp("LAMPU JAUH", if (telemetry.highBeam) "AKTIF" else "MATI", telemetry.highBeam)
                StatusLamp("MESIN", if (telemetry.checkEngine) "PERIKSA" else "NORMAL", !telemetry.checkEngine)
            }
        }
        Text("RPM dan indikator kendaraan membutuhkan data sensor/ESP yang sesuai. Kecepatan GPS membutuhkan izin lokasi.",
            color = Color.Gray, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun StatusLamp(title: String, value: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Color.Gray, fontSize = 9.sp)
        Text(value, color = if (active) NeonBlue else Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
