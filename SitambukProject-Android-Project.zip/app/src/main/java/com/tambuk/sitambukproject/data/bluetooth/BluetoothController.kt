package com.tambuk.sitambukproject.data.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.tambuk.sitambukproject.data.model.BluetoothConnectionState
import com.tambuk.sitambukproject.data.model.VehicleTelemetry
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

class BluetoothController(private val context: Context) {
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val _connectionState = MutableStateFlow(BluetoothConnectionState.DISCONNECTED)
    val connectionState: StateFlow<BluetoothConnectionState> = _connectionState.asStateFlow()

    private val _connectedDeviceName = MutableStateFlow<String?>(null)
    val connectedDeviceName: StateFlow<String?> = _connectedDeviceName.asStateFlow()

    private val _telemetryFlow = MutableStateFlow(VehicleTelemetry())
    val telemetryFlow: StateFlow<VehicleTelemetry> = _telemetryFlow.asStateFlow()

    private val _isDataStale = MutableStateFlow(false)
    val isDataStale: StateFlow<Boolean> = _isDataStale.asStateFlow()

    private var socket: BluetoothSocket? = null
    private var workerJob: Job? = null
    private var watchdogJob: Job? = null
    private var lastPacketTime = 0L

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<Pair<String, String>> {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return emptyList()
        return bluetoothAdapter.bondedDevices.map { (it.name ?: "Unknown") to it.address }
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(macAddress: String) {
        disconnect()
        _connectionState.value = BluetoothConnectionState.CONNECTING

        workerJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val device: BluetoothDevice = bluetoothAdapter?.getRemoteDevice(macAddress)
                    ?: throw Exception("Device not found")
                _connectedDeviceName.value = device.name ?: macAddress

                val localSocket = device.createRfcommSocketToServiceRecord(sppUuid)
                bluetoothAdapter?.cancelDiscovery()
                localSocket.connect()
                socket = localSocket

                _connectionState.value = BluetoothConnectionState.CONNECTED
                lastPacketTime = System.currentTimeMillis()
                startWatchdog()

                val reader = BufferedReader(InputStreamReader(localSocket.inputStream))
                while (isActive) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        parseTelemetry(line)
                    }
                }
            } catch (e: Exception) {
                _connectionState.value = BluetoothConnectionState.DISCONNECTED
            } finally {
                cleanUp()
            }
        }
    }

    private fun parseTelemetry(jsonString: String) {
        try {
            val parsed = json.decodeFromString<VehicleTelemetry>(jsonString)
            _telemetryFlow.value = parsed.copy(
                rpm = parsed.rpm.coerceIn(0f, 15000f),
                speed = parsed.speed.coerceIn(0f, 250f),
                batteryVoltage = parsed.batteryVoltage.coerceIn(0f, 20f),
                fuelPercent = parsed.fuelPercent?.coerceIn(0f, 100f)
            )
            lastPacketTime = System.currentTimeMillis()
            _isDataStale.value = false
        } catch (_: Exception) {}
    }

    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                delay(1500)
                if (_connectionState.value == BluetoothConnectionState.CONNECTED) {
                    if (System.currentTimeMillis() - lastPacketTime > 2500) {
                        _isDataStale.value = true
                    }
                }
            }
        }
    }

    fun disconnect() {
        workerJob?.cancel()
        watchdogJob?.cancel()
        cleanUp()
        _connectionState.value = BluetoothConnectionState.DISCONNECTED
        _connectedDeviceName.value = null
        _isDataStale.value = false
    }

    private fun cleanUp() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }
}
