package com.tambuk.sitambukproject.data.model

import kotlinx.serialization.Serializable

@Serializable
data class VehicleTelemetry(
    val rpm: Float = 0f,
    val speed: Float = 0f,
    val gear: String = "N",
    val fuelPercent: Float? = null,
    val leftTurn: Boolean = false,
    val rightTurn: Boolean = false,
    val highBeam: Boolean = false,
    val checkEngine: Boolean = false,
    val batteryVoltage: Float = 0f,
    val chargingVoltage: Float? = null,
    val temperatureC: Float? = null,
    val timestamp: Long = 0L
)

enum class BluetoothConnectionState {
    DISCONNECTED, CONNECTING, CONNECTED
}

enum class SpeedSource {
    GPS_ONLY, SENSOR_ESP32, AUTO
}
