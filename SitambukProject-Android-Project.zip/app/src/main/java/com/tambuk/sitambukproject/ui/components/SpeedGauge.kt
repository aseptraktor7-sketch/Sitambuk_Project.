package com.tambuk.sitambukproject.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tambuk.sitambukproject.ui.theme.NeonBlue
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedGauge(currentSpeed: Float, speedSourceLabel: String, modifier: Modifier = Modifier) {
    val maxSpeed = 160f
    val animatedSpeed by animateFloatAsState(
        targetValue = currentSpeed.coerceIn(0f, maxSpeed),
        animationSpec = tween(80),
        label = "SpeedAnim"
    )

    val startAngle = 135f
    val sweepAngle = 270f
    val needleAngle = startAngle + (animatedSpeed / maxSpeed) * sweepAngle

    Box(modifier = modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = size.width / 2 - 20f

            drawArc(
                color = Color(0xFF14202C),
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                style = Stroke(width = 14f, cap = StrokeCap.Round)
            )

            drawArc(
                color = NeonBlue,
                startAngle = startAngle,
                sweepAngle = (animatedSpeed / maxSpeed) * sweepAngle,
                useCenter = false,
                style = Stroke(width = 16f, cap = StrokeCap.Round)
            )

            for (i in 0..16) {
                val tickAngle = Math.toRadians((startAngle + (i / 16f) * sweepAngle).toDouble())
                val isMajor = i % 2 == 0
                val tickLength = if (isMajor) 24f else 12f

                val startX = center.x + (radius - tickLength) * cos(tickAngle).toFloat()
                val startY = center.y + (radius - tickLength) * sin(tickAngle).toFloat()
                val endX = center.x + radius * cos(tickAngle).toFloat()
                val endY = center.y + radius * sin(tickAngle).toFloat()

                drawLine(
                    color = if (isMajor) NeonBlue else Color.DarkGray,
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = if (isMajor) 4f else 2f,
                    cap = StrokeCap.Round
                )
            }

            rotate(degrees = needleAngle, pivot = center) {
                drawLine(
                    color = NeonBlue,
                    start = center,
                    end = Offset(center.x + radius - 30f, center.y),
                    strokeWidth = 6f,
                    cap = StrokeCap.Round
                )
            }

            drawCircle(color = Color(0xFF0D1622), radius = 32f, center = center)
            drawCircle(color = NeonBlue, radius = 8f, center = center)
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 70.dp)
        ) {
            Text(
                text = "${animatedSpeed.toInt()}",
                color = Color.White,
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "km/h",
                color = NeonBlue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "[$speedSourceLabel]",
                color = Color.Gray,
                fontSize = 9.sp
            )
        }
    }
}
