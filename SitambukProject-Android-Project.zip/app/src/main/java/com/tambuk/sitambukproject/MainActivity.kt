package com.tambuk.sitambukproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tambuk.sitambukproject.ui.MainViewModel
import com.tambuk.sitambukproject.ui.screens.*
import com.tambuk.sitambukproject.ui.theme.SitambukTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SitambukTheme {
                val nav = rememberNavController()
                val vm: MainViewModel = viewModel()
                NavHost(navController = nav, startDestination = "dashboard") {
                    composable("dashboard") { DashboardScreen(vm, { nav.navigate("settings") }, { nav.navigate("map") }, { nav.navigate("about") }) }
                    composable("settings") { SettingsScreen(vm) { nav.popBackStack() } }
                    composable("map") { MapScreen { nav.popBackStack() } }
                    composable("about") { AboutScreen { nav.popBackStack() } }
                }
            }
        }
    }
}
