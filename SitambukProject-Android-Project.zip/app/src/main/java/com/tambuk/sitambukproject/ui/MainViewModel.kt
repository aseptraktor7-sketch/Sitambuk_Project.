package com.tambuk.sitambukproject.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tambuk.sitambukproject.data.bluetooth.BluetoothController
import com.tambuk.sitambukproject.data.gps.LocationSpeedProvider
import com.tambuk.sitambukproject.data.model.BluetoothConnectionState
import com.tambuk.sitambukproject.data.model.SpeedSource
import com.tambuk.sitambukproject.data.model.VehicleTelemetry
import com.tambuk.sitambukproject.data.preferences.AppPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val bluetoothController = BluetoothController(application)
    val locationProvider = LocationSpeedProvider(application)
    val preferences = AppPreferences(application)

    val telemetry: StateFlow<VehicleTelemetry> = bluetoothController.telemetryFlow
    val btState: StateFlow<BluetoothConnectionState> = bluetoothController.connectionState
    val connectedDeviceName: StateFlow<String?> = bluetoothController.connectedDeviceName
    val isDataStale: StateFlow<Boolean> = bluetoothController.isDataStale

    private val _currentTime = MutableStateFlow("")
    val currentTime: StateFlow<String> = _currentTime.asStateFlow()

    val speedSource: StateFlow<SpeedSource> = preferences.speedSource.stateIn(
        viewModelScope, SharingStarted.Eagerly, SpeedSource.AUTO
    )
    val showTempSensor: StateFlow<Boolean> = preferences.showTempSensor.stateIn(
        viewModelScope, SharingStarted.Eagerly, true
    )

    init {
        viewModelScope.launch {
            val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            while (true) {
                _currentTime.value = formatter.format(Date())
                delay(1000)
            }
        }

        viewModelScope.launch {
            preferences.macAddress.firstOrNull()?.let { savedMac ->
                if (savedMac.isNotBlank()) {
                    bluetoothController.connectToDevice(savedMac)
                }
            }
        }

        locationProvider.startLocationUpdates()
    }

    fun getEffectiveSpeed(): Float {
        val espSpeed = telemetry.value.speed
        val gpsSpeed = locationProvider.gpsSpeedKmH.value

        return when (speedSource.value) {
            SpeedSource.GPS_ONLY -> gpsSpeed
            SpeedSource.SENSOR_ESP32 -> espSpeed
            SpeedSource.AUTO -> {
                if (btState.value == BluetoothConnectionState.CONNECTED && !isDataStale.value && espSpeed >= 0f) {
                    espSpeed
                } else {
                    gpsSpeed
                }
            }
        }
    }

    fun getSpeedSourceActiveLabel(): String {
        return when (speedSource.value) {
            SpeedSource.GPS_ONLY -> "GPS"
            SpeedSource.SENSOR_ESP32 -> "ESP32"
            SpeedSource.AUTO -> if (btState.value == BluetoothConnectionState.CONNECTED && !isDataStale.value) "ESP" else "GPS"
        }
    }

    override fun onCleared() {
        super.onCleared()
        locationProvider.stopLocationUpdates()
        bluetoothController.disconnect()
    }
}
