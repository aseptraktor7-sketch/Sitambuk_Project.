# Sitambuk_Project⚡

Proyek Android native Kotlin + Jetpack Compose. Build debug APK memakai JDK 17 dan Gradle 8.2+.

## Build melalui GitHub Actions (bisa dari HP)
1. Buat repository GitHub baru dan upload seluruh isi folder proyek ini (bukan file ZIP sebagai satu file).
2. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
3. Buka tab Actions, pilih `Build Sitambuk APK`, lalu tekan `Run workflow`.
4. Setelah proses hijau/sukses, buka hasil run dan unduh artifact `SitambukProject-debug-apk`.
5. Ekstrak ZIP artifact untuk mengambil `app-debug.apk`, lalu instal di Android.

Catatan: ini APK debug untuk pengujian. Data RPM dan indikator sensor akan tetap nol/tidak akurat sebelum board mengirim baris JSON yang sesuai melalui Bluetooth serial. GPS memerlukan izin lokasi. Google Maps API key belum disediakan sehingga layar peta ini masih berupa placeholder. Temperatur mesin tidak ditampilkan pada dashboard.
